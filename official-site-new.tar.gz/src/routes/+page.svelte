<script lang="ts">
  import { onMount } from "svelte";
  import anime from "animejs";

  import Carousel from "svelte-carousel";
  let carousel; // for calling methods of the carousel instance

  onMount(() => {
    anime({
      targets: "#texts > #I",
      translateY: ["150%", "0%"],
      opacity: [0, 1],
      duration: 1300,
      easing: "easeOutCubic",
    });
    anime({
      targets: "#texts > #I > span",
      translateY: ["70%", "0%"],
      opacity: [0, 1],
      delay: 400,
      duration: 1500,
      easing: "easeOutCubic",
    });
    anime({
      targets: "#texts > #II",
      translateY: ["40%", "0%"],
      opacity: [0, 1],
      delay: 900,
      duration: 1600,
      easing: "easeOutCubic",
    });
  });
</script>

<div id="grant" class="relative bg-slate-800">
  <Carousel
    bind:this={carousel}
    autoplay
    autoplayProgressVisible
    let:currentPageIndex
    let:pagesCount
    let:showPage
  >
    <button type="button" slot="prev" class="custom-arrow custom-arrow-prev">
      <i />
    </button>
    <div class="image bg-[url('/src/assets/img/mc1.jpg')]" />
    <div class="image bg-[url('/src/assets/img/mc1.jpg')]" />
    <button type="button" slot="next" class="custom-arrow custom-arrow-next">
      <i />
    </button>
  </Carousel>

  <div id="texts" class="absolute right-1/7 top-4/8">
    <p id="I" class="text-slate-300 text-4xl">YOUR TECHNOLOGICAL SERVER<span class="inline-block">,</span></p>
    <p id="II" class="text-slate-300 text-4xl">
      BUT WITH MORE <span class="text-red-500">NOVELTY</span>.
    </p>
  </div>
</div>

<div id="info" class="w-full py-1 flex justify-around bg-zinc-950">
  <div>
    <p class="prop-name">MODS</p>
    <p class="prop-value">
      IC2, BC, RC, RP, AE, OC、林业、家具、东方女仆、中式工坊<br>
      等涵盖电力、自动化、运输、装饰的五十八个 mod
    </p>
    <p class="prop-subvalue">基于 FORGE 平台</p>
  </div>
  <div>
    <p class="prop-name">PLUGINS</p>
    <p class="prop-value">
      NewHonor（称号）、RealMap（自定义地图图像）等丰富玩法之插件<br>
      以及数个关于领地 / 财产保护、经济 / 商店的插件
    </p>
    <p class="prop-subvalue">基于 SPONGE 平台</p>
  </div>
  <div>
    <p class="prop-name">VERSION</p>
    <p class="prop-value">1.12.2</p>
  </div>
</div>



<style>
  #grant .image {
    --at-apply: img-container w-full h-70v max-h-150 min-h-130 w-full bg-cover
      bg-center;
  }
  #info .prop-name {
    --at-apply: font-semibold text-zinc-400 text-sm;
  }
  #info .prop-value {
    --at-apply: font-normal text-zinc-500 text-xs;
  }
  #info .prop-subvalue {
    --at-apply: font-italic text-zinc-800 text-xs;
  }
  :global(#grant .sc-carousel-dots__container) {
    --at-apply: relative h-0 bottom-8;
  }
</style>
