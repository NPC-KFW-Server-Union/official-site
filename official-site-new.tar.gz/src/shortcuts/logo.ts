export const logo = { logo: 'i-logos:svelte-icon w-7em h-7em transform transition-300' }
